# Cypher Descriptions 

## Crail

### Magnetic Attack Drill
**Usable:** Small sphere with a thick screw protrusion
**Effect:** The user throws this cypher at a target within short range, and it drills into the target for one round, inflicting damage equal to the cypher level. If the target is made of metal or wearing metal (such as armor), the difficulty of the attack is decreased by one step.

### Monoblade
**Wearable:** Glove
**Effect:** Produces a 6-inch (15 cm) blade that’s the same level as the cypher. The blade cuts through any material of a level lower than its own. If used as a weapon, it is a light weapon that ignores Armor of a level lower than its own. The blade lasts for ten minutes.

## Etolas

### Datasphere Siphon
**Wearable:** Crystal worn on temple
**Effect:** Tapping into the datasphere’s knowledge, the user can learn the answer to one question.

### Eagleseye
**Usable:** Injector
**Effect:** Grants the ability to see ten times as far as normal for one hour.

### Friction-Reducing Gel
**Usable:** Spray canister
**Effect:** Sprayed across an area up to 10 feet (3 m) square, this gel makes things extremely slippery. For one hour, the difficulty of movement tasks in the area is increased by three steps.

## Haro

### Sheen
**Internal:** Pill
**Effect:** For one week, the user’s cells are coated with a protective veneer that resists damage (+1 to Armor) and decreases the difficulty of Might defense rolls by two steps. However, healing is more difficult during this time; all recovery rolls suffer a –1 penalty.

### Stim
**Usable:** Injector
**Effect:** Decreases the difficulty of the next action taken by three steps.

### Catseye
**Internal:** Ingestible liquid
**Effect:** Grants the ability to see in the dark for eight hours.

## Karner

### Detonation (Sonic)
**Usable:** Ceramic sphere (thrown, short range)
**Effect:** Explodes with terrifying sound, deafening all in an immediate radius.

### Instant Servant
**Usable:** Handheld device
**Effect:** Small device expands into a humanoid automaton that is roughly 2 feet (0.6 m) tall. It is a creature equal to the cypher level and can understand the verbal commands of the character who activates it. Once activated, commanding the servant is not an action. It can make attacks or perform actions as ordered to the best of its abilities, but it cannot speak.
  The automaton has short-range movement but never goes farther than long range away from the character who activated it. At the GM’s discretion, the servant might have specialized knowledge, such as how to operate a particular device. Otherwise, it has no special knowledge. In any case, the servant is not artificially intelligent or capable of initiating action. It does only as commanded.
  The servant operates for one hour per cypher level.

### Tanasia

### Detonation (Gravity)
**Wearable:** Wristband projector (long range)
**Effect:** Bursts in an immediate radius, inflicting damage equal to the cypher level by increasing gravity tremendously for one second. All in the area are crushed to the ground for one round and cannot take physical actions.

### Gravity-Nullifying Spray
**Usable:** Spray canister
**Effect:** A nonliving object about the size of a person or smaller sprayed by this cypher floats 1d20 feet in the air permanently and no longer has weight if carried (though it needs to be strapped dow

## Uraz

### Density Nodule
**Usable:** Crystal nodule affixed to a melee weapon
**Effect:** For the next 28 hours, each time the weapon the nodule is attached to strikes a solid creature or object, the weapon suddenly increases dramatically in weight, causing the blow to inflict an additional 2 points of damage.

### Force Shield Projector
**Internal:** Subdermal injection
**Effect:** Creates a shimmering energy shield around the user for one hour, during which time he gains +4 Armor.
